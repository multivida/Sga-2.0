<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/admin' => [[['_route' => 'admin_index', '_controller' => 'App\\Controller\\Admin\\AdminController::index'], null, null, null, true, false, null]],
        '/admin/acumular_atendimentos' => [[['_route' => 'admin_acumular_atendimentos', '_controller' => 'App\\Controller\\Admin\\AdminController::acumularAtendimentos'], null, ['POST' => 0], null, false, false, null]],
        '/admin/limpar_atendimentos' => [[['_route' => 'admin_limpar_atendimentos', '_controller' => 'App\\Controller\\Admin\\AdminController::limparAtendimentos'], null, ['POST' => 0], null, false, false, null]],
        '/admin/api' => [[['_route' => 'admin_api_index', '_controller' => 'App\\Controller\\Admin\\ApiController::index'], null, null, null, true, false, null]],
        '/admin/api/oauth-clients' => [
            [['_route' => 'admin_api_clients', '_controller' => 'App\\Controller\\Admin\\ApiController::oauthClients'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'admin_api_newclient', '_controller' => 'App\\Controller\\Admin\\ApiController::newOauthClient'], null, ['POST' => 0], null, false, false, null],
        ],
        '/admin/departamentos' => [[['_route' => 'admin_departamentos_index', '_controller' => 'App\\Controller\\Admin\\DepartamentoController::index'], null, null, null, true, false, null]],
        '/admin/departamentos/new' => [[['_route' => 'admin_departamentos_new', '_controller' => 'App\\Controller\\Admin\\DepartamentoController::form'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/locais' => [[['_route' => 'admin_locais_index', '_controller' => 'App\\Controller\\Admin\\LocaisController::index'], null, null, null, true, false, null]],
        '/admin/locais/new' => [[['_route' => 'admin_locais_new', '_controller' => 'App\\Controller\\Admin\\LocaisController::form'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/modulos' => [[['_route' => 'admin_modulos_index', '_controller' => 'App\\Controller\\Admin\\ModulosController::index'], null, null, null, true, false, null]],
        '/admin/modulos/update' => [[['_route' => 'admin_modulos_update', '_controller' => 'App\\Controller\\Admin\\ModulosController::update'], null, null, null, false, false, null]],
        '/admin/perfis' => [[['_route' => 'admin_perfis_index', '_controller' => 'App\\Controller\\Admin\\PerfisController::index'], null, null, null, true, false, null]],
        '/admin/perfis/new' => [[['_route' => 'admin_perfis_new', '_controller' => 'App\\Controller\\Admin\\PerfisController::form'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/prioridades' => [[['_route' => 'admin_prioridades_index', '_controller' => 'App\\Controller\\Admin\\PrioridadesController::index'], null, null, null, true, false, null]],
        '/admin/prioridades/new' => [[['_route' => 'admin_prioridades_new', '_controller' => 'App\\Controller\\Admin\\PrioridadesController::form'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/servicos' => [[['_route' => 'admin_servicos_index', '_controller' => 'App\\Controller\\Admin\\ServicosController::index'], null, ['GET' => 0], null, true, false, null]],
        '/admin/servicos/new' => [[['_route' => 'admin_servicos_new', '_controller' => 'App\\Controller\\Admin\\ServicosController::form'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin/unidades' => [[['_route' => 'admin_unidades_index', '_controller' => 'App\\Controller\\Admin\\UnidadesController::index'], null, null, null, true, false, null]],
        '/admin/unidades/new' => [[['_route' => 'admin_unidades_new', '_controller' => 'App\\Controller\\Admin\\UnidadesController::form'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/api/agendamentos' => [
            [['_route' => 'app_api_agendamentos_post', '_controller' => 'App\\Controller\\Api\\AgendamentosController::post'], null, ['POST' => 0], null, false, false, null],
            [['_route' => 'app_api_agendamentos_dofind', '_controller' => 'App\\Controller\\Api\\AgendamentosController::doFind'], null, ['GET' => 0], null, false, false, null],
        ],
        '/api/atendimentos' => [[['_route' => 'app_api_atendimentos_dofind', '_controller' => 'App\\Controller\\Api\\AtendimentosController::doFind'], null, ['GET' => 0], null, false, false, null]],
        '/api/atendimentoshistorico' => [[['_route' => 'app_api_atendimentoshistorico_dofind', '_controller' => 'App\\Controller\\Api\\AtendimentosHistoricoController::doFind'], null, ['GET' => 0], null, false, false, null]],
        '/api' => [
            [['_route' => 'app_api_default_index', '_controller' => 'App\\Controller\\Api\\DefaultController::index'], null, null, null, false, false, null],
            [['_route' => 'app_api_default_index_1', '_controller' => 'App\\Controller\\Api\\DefaultController::index'], null, null, null, true, false, null],
        ],
        '/api/departamentos' => [
            [['_route' => 'app_api_departamentos_dofind', '_controller' => 'App\\Controller\\Api\\DepartamentosController::doFind'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'app_api_departamentos_dopost', '_controller' => 'App\\Controller\\Api\\DepartamentosController::doPost'], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/filas' => [[['_route' => 'app_api_filas_alterastatus', '_controller' => 'App\\Controller\\Api\\FilasController::alteraStatus'], null, ['PUT' => 0], null, false, false, null]],
        '/api/locais' => [
            [['_route' => 'app_api_locais_dofind', '_controller' => 'App\\Controller\\Api\\LocaisController::doFind'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'app_api_locais_dopost', '_controller' => 'App\\Controller\\Api\\LocaisController::doPost'], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/prioridades' => [
            [['_route' => 'app_api_prioridades_dofind', '_controller' => 'App\\Controller\\Api\\PrioridadesController::doFind'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'app_api_prioridades_dopost', '_controller' => 'App\\Controller\\Api\\PrioridadesController::doPost'], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/servicos' => [
            [['_route' => 'app_api_servicos_dofind', '_controller' => 'App\\Controller\\Api\\ServicosController::doFind'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'app_api_servicos_dopost', '_controller' => 'App\\Controller\\Api\\ServicosController::doPost'], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/distribui' => [[['_route' => 'app_api_triagem_distribui', '_controller' => 'App\\Controller\\Api\\TriagemController::distribui'], null, ['POST' => 0], null, false, false, null]],
        '/api/unidades' => [
            [['_route' => 'app_api_unidades_dofind', '_controller' => 'App\\Controller\\Api\\UnidadesController::doFind'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'app_api_unidades_dopost', '_controller' => 'App\\Controller\\Api\\UnidadesController::doPost'], null, ['POST' => 0], null, false, false, null],
        ],
        '/api/usuarios' => [[['_route' => 'app_api_usuarios_dofind', '_controller' => 'App\\Controller\\Api\\UsuariosController::doFind'], null, ['GET' => 0], null, false, false, null]],
        '/' => [[['_route' => 'home', '_controller' => 'App\\Controller\\DefaultController::index'], null, null, null, false, false, null]],
        '/about' => [[['_route' => 'about', '_controller' => 'App\\Controller\\DefaultController::about'], null, null, null, false, false, null]],
        '/unidades' => [[['_route' => 'app_default_unidades', '_controller' => 'App\\Controller\\DefaultController::unidades'], null, ['GET' => 0], null, false, false, null]],
        '/menu' => [[['_route' => 'app_default_menu', '_controller' => 'App\\Controller\\DefaultController::menu'], null, ['GET' => 0], null, false, false, null]],
        '/profile' => [[['_route' => 'profile_index', '_controller' => 'App\\Controller\\ProfileController::index'], null, ['GET' => 0, 'POST' => 1], null, true, false, null]],
        '/profile/password' => [[['_route' => 'app_profile_password', '_controller' => 'App\\Controller\\ProfileController::password'], null, ['POST' => 0], null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/login_check' => [[['_route' => 'login_check'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'logout'], null, null, null, false, false, null]],
        '/novosga.settings' => [[['_route' => 'novosga_settings_index', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::index'], null, ['GET' => 0], null, true, false, null]],
        '/novosga.settings/servicos' => [[['_route' => 'novosga_settings_servicos', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::servicos'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.settings/servicos_unidade' => [
            [['_route' => 'novosga_settings_servicos_unidade', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::servicosUnidade'], null, ['GET' => 0], null, false, false, null],
            [['_route' => 'novosga_settings_add_servico_unidade', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::addServico'], null, ['POST' => 0], null, false, false, null],
        ],
        '/novosga.settings/contadores' => [[['_route' => 'novosga_settings_contadores', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::contadores'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.settings/update_impressao' => [[['_route' => 'novosga_settings_update_impressao', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::updateImpressao'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.settings/limpar' => [[['_route' => 'novosga_settings_limpar_dados', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::limparDados'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.settings/acumular_atendimentos' => [[['_route' => 'novosga_settings_acumular_atendimentos', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::reiniciar'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.triage' => [[['_route' => 'novosga_triage_index', '_controller' => 'Novosga\\TriageBundle\\Controller\\DefaultController::index'], null, ['GET' => 0], null, true, false, null]],
        '/novosga.triage/ajax_update' => [[['_route' => 'novosga_triage_ajax_update', '_controller' => 'Novosga\\TriageBundle\\Controller\\DefaultController::ajaxUpdate'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.triage/servico_info' => [[['_route' => 'novosga_triage_servico_info', '_controller' => 'Novosga\\TriageBundle\\Controller\\DefaultController::servicoInfo'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.triage/distribui_senha' => [[['_route' => 'novosga_triage_distribui_senha', '_controller' => 'Novosga\\TriageBundle\\Controller\\DefaultController::distribuiSenha'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.triage/consulta_senha' => [[['_route' => 'novosga_triage_consulta_senha', '_controller' => 'Novosga\\TriageBundle\\Controller\\DefaultController::consultaSenha'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.triage/clientes' => [[['_route' => 'novosga_triage_clientes', '_controller' => 'Novosga\\TriageBundle\\Controller\\DefaultController::clientes'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.monitor' => [[['_route' => 'novosga_monitor_index', '_controller' => 'Novosga\\MonitorBundle\\Controller\\DefaultController::index'], null, ['GET' => 0], null, true, false, null]],
        '/novosga.monitor/ajax_update' => [[['_route' => 'novosga_monitor_ajaxupdate', '_controller' => 'Novosga\\MonitorBundle\\Controller\\DefaultController::ajaxUpdate'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.monitor/buscar' => [[['_route' => 'novosga_monitor_buscar', '_controller' => 'Novosga\\MonitorBundle\\Controller\\DefaultController::buscar'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.users' => [[['_route' => 'novosga_users_index', '_controller' => 'Novosga\\UsersBundle\\Controller\\DefaultController::index'], null, ['GET' => 0], null, true, false, null]],
        '/novosga.users/new' => [[['_route' => 'novosga_users_new', '_controller' => 'Novosga\\UsersBundle\\Controller\\DefaultController::form'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/novosga.users/novalotacao' => [[['_route' => 'novosga_users_default_novalotacao', '_controller' => 'Novosga\\UsersBundle\\Controller\\DefaultController::novaLotacao'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.users/unidades' => [[['_route' => 'novosga_users_default_unidades', '_controller' => 'Novosga\\UsersBundle\\Controller\\DefaultController::unidades'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.reports' => [[['_route' => 'novosga_reports_index', '_controller' => 'Novosga\\ReportsBundle\\Controller\\DefaultController::index'], null, ['GET' => 0], null, true, false, null]],
        '/novosga.reports/chart' => [[['_route' => 'novosga_reports_chart', '_controller' => 'Novosga\\ReportsBundle\\Controller\\DefaultController::chart'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.reports/report' => [[['_route' => 'novosga_reports_report', '_controller' => 'Novosga\\ReportsBundle\\Controller\\DefaultController::report'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.attendance' => [[['_route' => 'novosga_attendance_index', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::index'], null, ['GET' => 0], null, true, false, null]],
        '/novosga.attendance/set_local' => [[['_route' => 'novosga_attendance_setlocal', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::setLocal'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.attendance/ajax_update' => [[['_route' => 'novosga_attendance_ajaxupdate', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::ajaxUpdate'], null, ['GET' => 0], null, false, false, null]],
        '/novosga.attendance/chamar' => [[['_route' => 'novosga_attendance_chamar', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::chamar'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.attendance/iniciar' => [[['_route' => 'novosga_attendance_iniciar', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::iniciar'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.attendance/nao_compareceu' => [[['_route' => 'novosga_attendance_naocompareceu', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::naoCompareceu'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.attendance/encerrar' => [[['_route' => 'novosga_attendance_encerrar', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::encerrar'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.attendance/redirecionar' => [[['_route' => 'novosga_attendance_redirecionar', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::redirecionar'], null, ['POST' => 0], null, false, false, null]],
        '/novosga.attendance/consulta_senha' => [[['_route' => 'novosga_attendance_consultasenha', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::consultaSenha'], null, ['GET' => 0], null, false, false, null]],
        '/api/token' => [[['_route' => 'fos_oauth_server_token', '_controller' => 'fos_oauth_server.controller.token:tokenAction', 'route' => 'fos_oauth_server_token'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/a(?'
                    .'|dmin/(?'
                        .'|api/oauth\\-clients/([^/]++)(*:47)'
                        .'|departamentos/([^/]++)(?'
                            .'|(*:79)'
                        .')'
                        .'|locais/([^/]++)(?'
                            .'|(*:105)'
                        .')'
                        .'|p(?'
                            .'|erfis/([^/]++)(?'
                                .'|(*:135)'
                            .')'
                            .'|rioridades/([^/]++)(?'
                                .'|(*:166)'
                            .')'
                        .')'
                        .'|servicos/([^/]++)(?'
                            .'|(*:196)'
                        .')'
                        .'|unidades/([^/]++)(?'
                            .'|(*:225)'
                        .')'
                    .')'
                    .'|pi/(?'
                        .'|a(?'
                            .'|gendamentos/([^/]++)(*:265)'
                            .'|tendimentos(?'
                                .'|/([^/]++)(*:296)'
                                .'|historico/([^/]++)(*:322)'
                            .')'
                        .')'
                        .'|departamentos/([^/]++)(?'
                            .'|(*:357)'
                        .')'
                        .'|filas/([^/]++)(*:380)'
                        .'|locais/([^/]++)(?'
                            .'|(*:406)'
                        .')'
                        .'|u(?'
                            .'|nidades/([^/]++)(?'
                                .'|/(?'
                                    .'|painel(*:448)'
                                    .'|servicos(*:464)'
                                    .'|atendimentos(*:484)'
                                .')'
                                .'|(*:493)'
                            .')'
                            .'|suarios/([^/]++)(*:518)'
                        .')'
                        .'|pri(?'
                            .'|oridades/([^/]++)(?'
                                .'|(*:553)'
                            .')'
                            .'|nt/([^/]++)(*:573)'
                        .')'
                        .'|servicos/([^/]++)(?'
                            .'|(*:602)'
                        .')'
                    .')'
                .')'
                .'|/set_unidade/([^/]++)(*:634)'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:673)'
                    .'|wdt/([^/]++)(*:693)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:739)'
                            .'|router(*:753)'
                            .'|exception(?'
                                .'|(*:773)'
                                .'|\\.css(*:786)'
                            .')'
                        .')'
                        .'|(*:796)'
                    .')'
                .')'
                .'|/novosga\\.(?'
                    .'|settings/(?'
                        .'|servico(?'
                            .'|s_unidade/([^/]++)(?'
                                .'|(*:862)'
                            .')'
                            .'|_usuario/([^/]++)/([^/]++)(?'
                                .'|(*:900)'
                            .')'
                        .')'
                        .'|reiniciar/([^/]++)(*:928)'
                        .'|usuario/([^/]++)(*:952)'
                    .')'
                    .'|triage/(?'
                        .'|imprimir/([^/]++)(*:988)'
                        .'|distribui_agendamento/([^/]++)(*:1026)'
                        .'|agendamentos/([^/]++)(*:1056)'
                    .')'
                    .'|monitor/(?'
                        .'|info_senha/([^/]++)(*:1096)'
                        .'|transferir/([^/]++)(*:1124)'
                        .'|reativar/([^/]++)(*:1150)'
                        .'|cancelar/([^/]++)(*:1176)'
                    .')'
                    .'|users/(?'
                        .'|([^/]++)/edit(*:1208)'
                        .'|p(?'
                            .'|erfis/([^/]++)(*:1235)'
                            .'|assword/([^/]++)(*:1260)'
                        .')'
                    .')'
                    .'|attendance/(?'
                        .'|info_senha/([^/]++)(*:1304)'
                        .'|usuarios/([^/]++)(*:1330)'
                    .')'
                .')'
            .')/?$}sD',
    ],
    [ // $dynamicRoutes
        47 => [[['_route' => 'admin_api_removeclient', '_controller' => 'App\\Controller\\Admin\\ApiController::removeOauthClient'], ['id'], ['DELETE' => 0], null, false, true, null]],
        79 => [
            [['_route' => 'admin_departamentos_edit', '_controller' => 'App\\Controller\\Admin\\DepartamentoController::form'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [['_route' => 'admin_departamentos_delete', '_controller' => 'App\\Controller\\Admin\\DepartamentoController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        105 => [
            [['_route' => 'admin_locais_edit', '_controller' => 'App\\Controller\\Admin\\LocaisController::form'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [['_route' => 'admin_locais_delete', '_controller' => 'App\\Controller\\Admin\\LocaisController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        135 => [
            [['_route' => 'admin_perfis_edit', '_controller' => 'App\\Controller\\Admin\\PerfisController::form'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [['_route' => 'admin_perfis_delete', '_controller' => 'App\\Controller\\Admin\\PerfisController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        166 => [
            [['_route' => 'admin_prioridades_edit', '_controller' => 'App\\Controller\\Admin\\PrioridadesController::form'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [['_route' => 'admin_prioridades_delete', '_controller' => 'App\\Controller\\Admin\\PrioridadesController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        196 => [
            [['_route' => 'admin_servicos_edit', '_controller' => 'App\\Controller\\Admin\\ServicosController::form'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [['_route' => 'admin_servicos_delete', '_controller' => 'App\\Controller\\Admin\\ServicosController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        225 => [
            [['_route' => 'admin_unidades_edit', '_controller' => 'App\\Controller\\Admin\\UnidadesController::form'], ['id'], ['GET' => 0, 'POST' => 1], null, false, true, null],
            [['_route' => 'admin_unidades_delete', '_controller' => 'App\\Controller\\Admin\\UnidadesController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        265 => [[['_route' => 'app_api_agendamentos_doget', '_controller' => 'App\\Controller\\Api\\AgendamentosController::doGet'], ['id'], ['GET' => 0], null, false, true, null]],
        296 => [[['_route' => 'app_api_atendimentos_doget', '_controller' => 'App\\Controller\\Api\\AtendimentosController::doGet'], ['id'], ['GET' => 0], null, false, true, null]],
        322 => [[['_route' => 'app_api_atendimentoshistorico_doget', '_controller' => 'App\\Controller\\Api\\AtendimentosHistoricoController::doGet'], ['id'], ['GET' => 0], null, false, true, null]],
        357 => [
            [['_route' => 'app_api_departamentos_doget', '_controller' => 'App\\Controller\\Api\\DepartamentosController::doGet'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_api_departamentos_doput', '_controller' => 'App\\Controller\\Api\\DepartamentosController::doPut'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_api_departamentos_dodelete', '_controller' => 'App\\Controller\\Api\\DepartamentosController::doDelete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        380 => [[['_route' => 'app_api_filas_atendimentosusuario', '_controller' => 'App\\Controller\\Api\\FilasController::atendimentosUsuario'], ['unidadeId'], ['GET' => 0], null, false, true, null]],
        406 => [
            [['_route' => 'app_api_locais_doget', '_controller' => 'App\\Controller\\Api\\LocaisController::doGet'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_api_locais_doput', '_controller' => 'App\\Controller\\Api\\LocaisController::doPut'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_api_locais_dodelete', '_controller' => 'App\\Controller\\Api\\LocaisController::doDelete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        448 => [[['_route' => 'app_api_painel_painel', '_controller' => 'App\\Controller\\Api\\PainelController::painel'], ['id'], ['GET' => 0], null, false, false, null]],
        464 => [[['_route' => 'app_api_unidades_servicos', '_controller' => 'App\\Controller\\Api\\UnidadesController::servicos'], ['id'], ['GET' => 0], null, false, false, null]],
        484 => [[['_route' => 'app_api_unidades_atendimentos', '_controller' => 'App\\Controller\\Api\\UnidadesController::atendimentos'], ['id'], ['GET' => 0], null, false, false, null]],
        493 => [
            [['_route' => 'app_api_unidades_doget', '_controller' => 'App\\Controller\\Api\\UnidadesController::doGet'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_api_unidades_doput', '_controller' => 'App\\Controller\\Api\\UnidadesController::doPut'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_api_unidades_dodelete', '_controller' => 'App\\Controller\\Api\\UnidadesController::doDelete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        518 => [[['_route' => 'app_api_usuarios_doget', '_controller' => 'App\\Controller\\Api\\UsuariosController::doGet'], ['id'], ['GET' => 0], null, false, true, null]],
        553 => [
            [['_route' => 'app_api_prioridades_doget', '_controller' => 'App\\Controller\\Api\\PrioridadesController::doGet'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_api_prioridades_doput', '_controller' => 'App\\Controller\\Api\\PrioridadesController::doPut'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_api_prioridades_dodelete', '_controller' => 'App\\Controller\\Api\\PrioridadesController::doDelete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        573 => [[['_route' => 'app_api_triagem_imprimir', '_controller' => 'App\\Controller\\Api\\TriagemController::imprimir'], ['id'], ['GET' => 0], null, false, true, null]],
        602 => [
            [['_route' => 'app_api_servicos_doget', '_controller' => 'App\\Controller\\Api\\ServicosController::doGet'], ['id'], ['GET' => 0], null, false, true, null],
            [['_route' => 'app_api_servicos_doput', '_controller' => 'App\\Controller\\Api\\ServicosController::doPut'], ['id'], ['PUT' => 0], null, false, true, null],
            [['_route' => 'app_api_servicos_dodelete', '_controller' => 'App\\Controller\\Api\\ServicosController::doDelete'], ['id'], ['DELETE' => 0], null, false, true, null],
        ],
        634 => [[['_route' => 'app_default_setunidade', '_controller' => 'App\\Controller\\DefaultController::setUnidade'], ['id'], ['POST' => 0], null, false, true, null]],
        673 => [[['_route' => '_twig_error_test', '_controller' => 'twig.controller.preview_error::previewErrorPageAction', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        693 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        739 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        753 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        773 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        786 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        796 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        862 => [
            [['_route' => 'novosga_settings_remove_servico_unidade', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::removeServicoUnidade'], ['id'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'novosga_settings_update_servicos_unidade', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::updateServico'], ['id'], ['PUT' => 0], null, false, true, null],
        ],
        900 => [
            [['_route' => 'novosga_settings_add_servico_usuario', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::addServicoUsuario'], ['usuarioId', 'servicoId'], ['POST' => 0], null, false, true, null],
            [['_route' => 'novosga_settings_remove_servico_usuario', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::removeServicoUsuario'], ['usuarioId', 'servicoId'], ['DELETE' => 0], null, false, true, null],
            [['_route' => 'novosga_settings_update_servico_usuario', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::updateServicoUsuario'], ['usuarioId', 'servicoId'], ['PUT' => 0], null, false, true, null],
        ],
        928 => [[['_route' => 'novosga_settings_reiniciar_contador', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::reiniciarContador'], ['id'], ['POST' => 0], null, false, true, null]],
        952 => [[['_route' => 'novosga_settings_update_usuario', '_controller' => 'Novosga\\SettingsBundle\\Controller\\DefaultController::updateUsuario'], ['id'], ['PUT' => 0], null, false, true, null]],
        988 => [[['_route' => 'novosga_triage_print', '_controller' => 'Novosga\\TriageBundle\\Controller\\DefaultController::imprimir'], ['id'], ['GET' => 0], null, false, true, null]],
        1026 => [[['_route' => 'novosga_triage_distribui_agendamento', '_controller' => 'Novosga\\TriageBundle\\Controller\\DefaultController::distribuiSenhaAgendamento'], ['id'], ['POST' => 0], null, false, true, null]],
        1056 => [[['_route' => 'novosga_triage_atendamentos', '_controller' => 'Novosga\\TriageBundle\\Controller\\DefaultController::agendamentos'], ['id'], ['GET' => 0], null, false, true, null]],
        1096 => [[['_route' => 'novosga_monitor_infosenha', '_controller' => 'Novosga\\MonitorBundle\\Controller\\DefaultController::infoSenha'], ['id'], ['GET' => 0], null, false, true, null]],
        1124 => [[['_route' => 'novosga_monitor_transferir', '_controller' => 'Novosga\\MonitorBundle\\Controller\\DefaultController::transferir'], ['id'], ['POST' => 0], null, false, true, null]],
        1150 => [[['_route' => 'novosga_monitor_reativar', '_controller' => 'Novosga\\MonitorBundle\\Controller\\DefaultController::reativar'], ['id'], ['POST' => 0], null, false, true, null]],
        1176 => [[['_route' => 'novosga_monitor_cancelar', '_controller' => 'Novosga\\MonitorBundle\\Controller\\DefaultController::cancelar'], ['id'], ['POST' => 0], null, false, true, null]],
        1208 => [[['_route' => 'novosga_users_edit', '_controller' => 'Novosga\\UsersBundle\\Controller\\DefaultController::form'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        1235 => [[['_route' => 'novosga_users_default_perfis', '_controller' => 'Novosga\\UsersBundle\\Controller\\DefaultController::perfis'], ['id'], ['GET' => 0], null, false, true, null]],
        1260 => [[['_route' => 'novosga_users_password', '_controller' => 'Novosga\\UsersBundle\\Controller\\DefaultController::password'], ['id'], ['POST' => 0], null, false, true, null]],
        1304 => [[['_route' => 'novosga_attendance_infosenha', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::infoSenha'], ['id'], ['GET' => 0], null, false, true, null]],
        1330 => [
            [['_route' => 'novosga_attendance_usuarios', '_controller' => 'Novosga\\AttendanceBundle\\Controller\\DefaultController::usuarios'], ['id'], ['GET' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
